<center>
    <center>
        <img src = images/project_workflow.png width = 35%/>
    </center>
</center>

## Data Set Information:

The data used in this project comes from anonymized credit card transactions. It contains 284,807 records with 30 features, among which 492 are labeled as fraudulent transactions. 

#### Business Understanding

##### What is Credit Card Fraud Detection?

Credit card fraud is a significant concern in the financial industry, leading to massive losses each year. Institutions seek intelligent systems that can proactively detect and block suspicious transactions before they complete. Fraud detection systems use historical transaction data to build predictive models capable of identifying fraud in real-time.

##### Why Machine Learning?

Fraudulent behaviors evolve over time and often follow hidden patterns. Traditional rule-based systems are insufficient to capture the complexity and variability of fraud. Machine learning models, especially those trained on large-scale labeled datasets, can learn subtle patterns, adapt over time, and offer better accuracy and generalization.

In this project, we leverage supervised learning techniques such as logistic regression, random forest, and support vector machines to classify transactions as fraudulent or legitimate. 

#### Source:

Kaggle - Credit Card Fraud Detection Dataset

## Data Understanding
<pre>
Data Set Characteristics:  Multivariate
Area: Finance, Anomaly Detection
Attribute Characteristics: Real
</pre>

####Information:

- **Time**: Seconds elapsed between this transaction and the first transaction in the dataset.
- **V1-V28**: Result of PCA transformation to preserve confidentiality.
- **Amount**: Transaction amount.
- **Class**: Target variable (1 = fraud, 0 = normal).

## Project Structure and Instructions
<pre>
├── data
│    ├── creditcard.csv
│    └── model
│        ├── fraud_detection_lr_model.joblib
├── draft document（useless）
│    ├── Project.ipynb
│    ├── Project.md
├── images
│    ├── output_4_0.png
│    ├── output_5_0.png
│    ├── output_7_0.png
├── presentation
 |   ├── project.pptx
├── 1. Predictive-maintenance_exploratory_data_analysis.ipynb
├── 2. Predictive_maintenance_machine_failure.ipynb
├── 3. Predictive_maintenance_component_failure.ipynb
├── README.md

</pre>

## Data Preparation and Visualization
<pre>
Code Used: Python
Packages: pandas, numpy, matplotlib, seaborn
</pre>

## Data Modeling and Evaluation
<pre>
Models: Logistic Regression, Random Forest, SVM
Packages: scikit-learn
Saved Model: Logistic Regression (.joblib)
</pre>

## Summary

- Logistic regression provided a balance of accuracy and simplicity.
- Class imbalance requires careful performance evaluation (F1-score, ROC-AUC).
This project demonstrates the full pipeline of a machine learning solution for fraud detection:
- from raw data to visualization,
- from preprocessing to training and evaluation,
- from modeling to saving reusable models.

<center>
    <img src = images/copyright.png width = 15%, align = "right"/>
</center>
