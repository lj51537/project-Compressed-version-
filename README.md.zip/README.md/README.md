### Credit Card Fraud Detection

**Yongzhi Tong**

#### Abstract
This project investigates the application of machine learning techniques to detect fraudulent credit card transactions. Using the popular imbalanced creditcard.csv dataset, four models—Logistic Regression, Random Forest, XGBoost, and a Neural Network—were trained and evaluated. Evaluation metrics such as precision, recall, F1-score, and ROC-AUC were used to compare model effectiveness. Results show that tree-based methods and neural networks outperform traditional logistic regression, especially in detecting rare fraudulent cases. Future work includes improving recall using advanced resampling techniques like SMOTE and tuning hyperparameters.

#### Rationale
Credit card fraud causes significant losses every year, and due to the rarity of fraudulent transactions and the difficulty of real-time detection, a reliable fraud detection system can enhance customer trust and improve the operational efficiency of financial institutions.

#### Research Question
I want to understand how effectively machine learning algorithms can detect fraudulent credit card transactions from large datasets.

#### Data Sources
The dataset used is Kaggle's credit card fraud detection dataset, which contains 284,807 transactions made by European cardholders in 2013. 

#### Methodology
Data preprocessing: Standardize temporal and quantitative features. Undersampling is performed to balance the dataset.
Model training: Logistic regression, Random Forest, XGBoost, Multilayer Perceptron (neural network).
Evaluation metrics: Accuracy, Precision, Recall, F1 value, Area under the ROC curve (AUC), Confusion matrix and visualization.

#### Results
Logistic Regression: ROC AUC score of 0.8678, moderate precision for fraud cases (0.0018), high recall (0.9837).
Random Forest: ROC AUC score of 0.8174, perfect recall (1.000) for fraud cases, very low precision (0.0017).
XGBoost: ROC AUC score of 0.5086, high recall (1.000), low precision (0.0018).
MLP (Neural Network): ROC AUC score (0.9565), high recall (1.000), low precision (0.0018).
The confusion matrix shows that most models flagged almost all fraud cases (high recall), but also produced many false positives (low precision).

#### Next steps
Address Class Imbalance: Experiment with advanced techniques instead of basic undersampling to improve precision.
Hyperparameter Tuning: Optimize model parameters to balance precision and recall.
Ensemble Methods: Test hybrid models to leverage strengths of individual algorithms.

#### Conclusion
Positive results: MLP and Logistic Regression showed high AUC scores, indicating good discrimination. All models achieved near-perfect recall.
Negative results: Low precision of each model resulted in high false positives. XGBoost results showed that it may not be suitable for this dataset without tuning.
Recommendations: Focus on improving precision to reduce operational costs caused by false positives.
Notes:Undersampling may produce biased results, use other sampling methods to verify the results.

### Bibliography 
Kaggle. Credit card fraud detection dataset. https://www.kaggle.com/mlg-ulb/creditcardfraud
Scikit-learn documentation. Classification metrics. https://scikit-learn.org/stable/modules/model_evaluation.html


##### Contact and Further Information